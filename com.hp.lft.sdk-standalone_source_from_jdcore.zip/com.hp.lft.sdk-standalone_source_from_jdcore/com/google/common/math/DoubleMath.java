package com.google.common.math;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.primitives.Booleans;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Iterator;




































public final class DoubleMath
{
  private static final double MIN_INT_AS_DOUBLE = -2.147483648E9D;
  private static final double MAX_INT_AS_DOUBLE = 2.147483647E9D;
  private static final double MIN_LONG_AS_DOUBLE = -9.223372036854776E18D;
  private static final double MAX_LONG_AS_DOUBLE_PLUS_ONE = 9.223372036854776E18D;
  
  static double roundIntermediate(double x, RoundingMode mode)
  {
    if (!DoubleUtils.isFinite(x)) {
      throw new ArithmeticException("input is infinite or NaN");
    }
    switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()]) {
    case 1: 
      MathPreconditions.checkRoundingUnnecessary(isMathematicalInteger(x));
      return x;
    
    case 2: 
      if ((x >= 0.0D) || (isMathematicalInteger(x))) {
        return x;
      }
      return x - 1.0D;
    

    case 3: 
      if ((x <= 0.0D) || (isMathematicalInteger(x))) {
        return x;
      }
      return x + 1.0D;
    

    case 4: 
      return x;
    
    case 5: 
      if (isMathematicalInteger(x)) {
        return x;
      }
      return x + Math.copySign(1.0D, x);
    

    case 6: 
      return Math.rint(x);
    
    case 7: 
      double z = Math.rint(x);
      if (Math.abs(x - z) == 0.5D) {
        return x + Math.copySign(0.5D, x);
      }
      return z;
    


    case 8: 
      double z = Math.rint(x);
      if (Math.abs(x - z) == 0.5D) {
        return x;
      }
      return z;
    }
    
    

    throw new AssertionError();
  }
  














  public static int roundToInt(double x, RoundingMode mode)
  {
    double z = roundIntermediate(x, mode);
    MathPreconditions.checkInRange((z > -2.147483649E9D ? 1 : 0) & (z < 2.147483648E9D ? 1 : 0));
    return (int)z;
  }
  
















  public static long roundToLong(double x, RoundingMode mode)
  {
    double z = roundIntermediate(x, mode);
    MathPreconditions.checkInRange((-9.223372036854776E18D - z < 1.0D ? 1 : 0) & (z < 9.223372036854776E18D ? 1 : 0));
    return z;
  }
  

















  public static BigInteger roundToBigInteger(double x, RoundingMode mode)
  {
    x = roundIntermediate(x, mode);
    if (((-9.223372036854776E18D - x < 1.0D ? 1 : 0) & (x < 9.223372036854776E18D ? 1 : 0)) != 0) {
      return BigInteger.valueOf(x);
    }
    int exponent = Math.getExponent(x);
    long significand = DoubleUtils.getSignificand(x);
    BigInteger result = BigInteger.valueOf(significand).shiftLeft(exponent - 52);
    return x < 0.0D ? result.negate() : result;
  }
  



  public static boolean isPowerOfTwo(double x)
  {
    return (x > 0.0D) && (DoubleUtils.isFinite(x)) && (LongMath.isPowerOfTwo(DoubleUtils.getSignificand(x)));
  }
  














  public static double log2(double x)
  {
    return Math.log(x) / LN_2;
  }
  
  private static final double LN_2 = Math.log(2.0D);
  



  @VisibleForTesting
  static final int MAX_FACTORIAL = 170;
  



  public static int log2(double x, RoundingMode mode)
  {
    Preconditions.checkArgument((x > 0.0D) && (DoubleUtils.isFinite(x)), "x must be positive and finite");
    int exponent = Math.getExponent(x);
    if (!DoubleUtils.isNormal(x)) {
      return log2(x * 4.503599627370496E15D, mode) - 52;
    }
    
    boolean increment;
    
    switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()]) {
    case 1: 
      MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
    
    case 2: 
      increment = false;
      break;
    case 3: 
      increment = !isPowerOfTwo(x);
      break;
    case 4: 
      increment = (exponent < 0 ? 1 : 0) & (!isPowerOfTwo(x) ? 1 : 0);
      break;
    case 5: 
      increment = (exponent >= 0 ? 1 : 0) & (!isPowerOfTwo(x) ? 1 : 0);
      break;
    case 6: 
    case 7: 
    case 8: 
      double xScaled = DoubleUtils.scaleNormalize(x);
      

      increment = xScaled * xScaled > 2.0D;
      break;
    default: 
      throw new AssertionError();
    }
    return increment ? exponent + 1 : exponent;
  }
  





  public static boolean isMathematicalInteger(double x)
  {
    return (DoubleUtils.isFinite(x)) && ((x == 0.0D) || (52 - Long.numberOfTrailingZeros(DoubleUtils.getSignificand(x)) <= Math.getExponent(x)));
  }
  










  public static double factorial(int n)
  {
    MathPreconditions.checkNonNegative("n", n);
    if (n > 170) {
      return Double.POSITIVE_INFINITY;
    }
    

    double accum = 1.0D;
    for (int i = 1 + (n & 0xFFFFFFF0); i <= n; i++) {
      accum *= i;
    }
    return accum * everySixteenthFactorial[(n >> 4)];
  }
  




  @VisibleForTesting
  static final double[] everySixteenthFactorial = { 1.0D, 2.0922789888E13D, 2.631308369336935E35D, 1.2413915592536073E61D, 1.2688693218588417E89D, 7.156945704626381E118D, 9.916779348709496E149D, 1.974506857221074E182D, 3.856204823625804E215D, 5.5502938327393044E249D, 4.7147236359920616E284D };
  



































  public static boolean fuzzyEquals(double a, double b, double tolerance)
  {
    MathPreconditions.checkNonNegative("tolerance", tolerance);
    return (Math.copySign(a - b, 1.0D) <= tolerance) || (a == b) || ((Double.isNaN(a)) && (Double.isNaN(b)));
  }
  

















  public static int fuzzyCompare(double a, double b, double tolerance)
  {
    if (fuzzyEquals(a, b, tolerance))
      return 0;
    if (a < b)
      return -1;
    if (a > b) {
      return 1;
    }
    return Booleans.compare(Double.isNaN(a), Double.isNaN(b));
  }
  
  private static final class MeanAccumulator {
    private MeanAccumulator() {}
    
    private long count = 0L;
    private double mean = 0.0D;
    
    void add(double value) {
      Preconditions.checkArgument(DoubleUtils.isFinite(value));
      count += 1L;
      
      mean += (value - mean) / count;
    }
    
    double mean() {
      Preconditions.checkArgument(count > 0L, "Cannot take mean of 0 values");
      return mean;
    }
  }
  



  public static double mean(double... values)
  {
    MeanAccumulator accumulator = new MeanAccumulator(null);
    for (double value : values) {
      accumulator.add(value);
    }
    return accumulator.mean();
  }
  



  public static double mean(int... values)
  {
    MeanAccumulator accumulator = new MeanAccumulator(null);
    for (int value : values) {
      accumulator.add(value);
    }
    return accumulator.mean();
  }
  




  public static double mean(long... values)
  {
    MeanAccumulator accumulator = new MeanAccumulator(null);
    for (long value : values) {
      accumulator.add(value);
    }
    return accumulator.mean();
  }
  




  public static double mean(Iterable<? extends Number> values)
  {
    MeanAccumulator accumulator = new MeanAccumulator(null);
    for (Number value : values) {
      accumulator.add(value.doubleValue());
    }
    return accumulator.mean();
  }
  




  public static double mean(Iterator<? extends Number> values)
  {
    MeanAccumulator accumulator = new MeanAccumulator(null);
    while (values.hasNext()) {
      accumulator.add(((Number)values.next()).doubleValue());
    }
    return accumulator.mean();
  }
  
  private DoubleMath() {}
}
