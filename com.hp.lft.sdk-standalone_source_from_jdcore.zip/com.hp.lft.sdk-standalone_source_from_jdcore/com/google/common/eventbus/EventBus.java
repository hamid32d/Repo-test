package com.google.common.eventbus;

import com.google.common.annotations.Beta;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;
import com.google.common.reflect.TypeToken;
import com.google.common.reflect.TypeToken.TypeSet;
import com.google.common.util.concurrent.UncheckedExecutionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

























































































@Beta
public class EventBus
{
  private static final LoadingCache<Class<?>, Set<Class<?>>> flattenHierarchyCache = CacheBuilder.newBuilder().weakKeys().build(new CacheLoader()
  {


    public Set<Class<?>> load(Class<?> concreteClass)
    {

      return TypeToken.of(concreteClass).getTypes().rawTypes();
    }
  });
  















  private final SetMultimap<Class<?>, EventHandler> handlersByType = HashMultimap.create();
  
  private final ReadWriteLock handlersByTypeLock = new ReentrantReadWriteLock();
  





  private final Logger logger;
  




  private final HandlerFindingStrategy finder = new AnnotatedHandlerFinder();
  

  private final ThreadLocal<Queue<EventWithHandler>> eventsToDispatch = new ThreadLocal()
  {
    protected Queue<EventBus.EventWithHandler> initialValue() {
      return new LinkedList();
    }
  };
  

  private final ThreadLocal<Boolean> isDispatching = new ThreadLocal()
  {
    protected Boolean initialValue() {
      return Boolean.valueOf(false);
    }
  };
  


  public EventBus()
  {
    this("default");
  }
  





  public EventBus(String identifier)
  {
    logger = Logger.getLogger(EventBus.class.getName() + "." + (String)Preconditions.checkNotNull(identifier));
  }
  







  public void register(Object object)
  {
    Multimap<Class<?>, EventHandler> methodsInListener = finder.findAllHandlers(object);
    
    handlersByTypeLock.writeLock().lock();
    try {
      handlersByType.putAll(methodsInListener);
    } finally {
      handlersByTypeLock.writeLock().unlock();
    }
  }
  





  public void unregister(Object object)
  {
    Multimap<Class<?>, EventHandler> methodsInListener = finder.findAllHandlers(object);
    for (Map.Entry<Class<?>, Collection<EventHandler>> entry : methodsInListener.asMap().entrySet()) {
      Class<?> eventType = (Class)entry.getKey();
      Collection<EventHandler> eventMethodsInListener = (Collection)entry.getValue();
      
      handlersByTypeLock.writeLock().lock();
      try {
        Set<EventHandler> currentHandlers = handlersByType.get(eventType);
        if (!currentHandlers.containsAll(eventMethodsInListener)) {
          throw new IllegalArgumentException("missing event handler for an annotated method. Is " + object + " registered?");
        }
        
        currentHandlers.removeAll(eventMethodsInListener);
      } finally {
        handlersByTypeLock.writeLock().unlock();
      }
    }
  }
  










  public void post(Object event)
  {
    Set<Class<?>> dispatchTypes = flattenHierarchy(event.getClass());
    
    boolean dispatched = false;
    for (Class<?> eventType : dispatchTypes) {
      handlersByTypeLock.readLock().lock();
      try {
        Set<EventHandler> wrappers = handlersByType.get(eventType);
        
        if (!wrappers.isEmpty()) {
          dispatched = true;
          for (EventHandler wrapper : wrappers) {
            enqueueEvent(event, wrapper);
          }
        }
      } finally {
        handlersByTypeLock.readLock().unlock();
      }
    }
    
    if ((!dispatched) && (!(event instanceof DeadEvent))) {
      post(new DeadEvent(this, event));
    }
    
    dispatchQueuedEvents();
  }
  




  void enqueueEvent(Object event, EventHandler handler)
  {
    ((Queue)eventsToDispatch.get()).offer(new EventWithHandler(event, handler));
  }
  






  void dispatchQueuedEvents()
  {
    if (((Boolean)isDispatching.get()).booleanValue()) {
      return;
    }
    
    isDispatching.set(Boolean.valueOf(true));
    try {
      Queue<EventWithHandler> events = (Queue)eventsToDispatch.get();
      EventWithHandler eventWithHandler;
      while ((eventWithHandler = (EventWithHandler)events.poll()) != null) {
        dispatch(event, handler);
      }
    } finally {
      isDispatching.remove();
      eventsToDispatch.remove();
    }
  }
  






  void dispatch(Object event, EventHandler wrapper)
  {
    try
    {
      wrapper.handleEvent(event);
    } catch (InvocationTargetException e) {
      logger.log(Level.SEVERE, "Could not dispatch event: " + event + " to handler " + wrapper, e);
    }
  }
  







  @VisibleForTesting
  Set<Class<?>> flattenHierarchy(Class<?> concreteClass)
  {
    try
    {
      return (Set)flattenHierarchyCache.getUnchecked(concreteClass);
    } catch (UncheckedExecutionException e) {
      throw Throwables.propagate(e.getCause());
    }
  }
  
  static class EventWithHandler {
    final Object event;
    final EventHandler handler;
    
    public EventWithHandler(Object event, EventHandler handler) {
      this.event = Preconditions.checkNotNull(event);
      this.handler = ((EventHandler)Preconditions.checkNotNull(handler));
    }
  }
}
