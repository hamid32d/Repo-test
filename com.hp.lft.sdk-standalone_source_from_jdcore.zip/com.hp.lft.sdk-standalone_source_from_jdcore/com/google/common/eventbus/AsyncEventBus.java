package com.google.common.eventbus;

import com.google.common.annotations.Beta;
import com.google.common.base.Preconditions;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;


























@Beta
public class AsyncEventBus
  extends EventBus
{
  private final Executor executor;
  private final ConcurrentLinkedQueue<EventBus.EventWithHandler> eventsToDispatch = new ConcurrentLinkedQueue();
  









  public AsyncEventBus(String identifier, Executor executor)
  {
    super(identifier);
    this.executor = ((Executor)Preconditions.checkNotNull(executor));
  }
  







  public AsyncEventBus(Executor executor)
  {
    this.executor = ((Executor)Preconditions.checkNotNull(executor));
  }
  
  void enqueueEvent(Object event, EventHandler handler)
  {
    eventsToDispatch.offer(new EventBus.EventWithHandler(event, handler));
  }
  




  protected void dispatchQueuedEvents()
  {
    for (;;)
    {
      EventBus.EventWithHandler eventWithHandler = (EventBus.EventWithHandler)eventsToDispatch.poll();
      if (eventWithHandler == null) {
        break;
      }
      
      dispatch(event, handler);
    }
  }
  



  void dispatch(final Object event, final EventHandler handler)
  {
    Preconditions.checkNotNull(event);
    Preconditions.checkNotNull(handler);
    executor.execute(new Runnable()
    {
      public void run()
      {
        AsyncEventBus.this.dispatch(event, handler);
      }
    });
  }
}
