package com.google.common.eventbus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;






























final class SynchronizedEventHandler
  extends EventHandler
{
  public SynchronizedEventHandler(Object target, Method method)
  {
    super(target, method);
  }
  
  public void handleEvent(Object event)
    throws InvocationTargetException
  {
    synchronized (this) {
      super.handleEvent(event);
    }
  }
}
