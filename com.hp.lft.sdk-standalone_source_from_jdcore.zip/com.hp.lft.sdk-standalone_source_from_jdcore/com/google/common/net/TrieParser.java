package com.google.common.net;

import com.google.common.annotations.GwtCompatible;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.common.collect.Lists;
import java.util.List;




















@GwtCompatible
class TrieParser
{
  private static final Joiner PREFIX_JOINER = Joiner.on("");
  

  TrieParser() {}
  
  static ImmutableSet<String> parseTrie(CharSequence encoded)
  {
    ImmutableSet.Builder<String> builder = ImmutableSet.builder();
    int encodedLen = encoded.length();
    int idx = 0;
    while (idx < encodedLen) {
      idx += doParseTrieToBuilder(Lists.newLinkedList(), encoded.subSequence(idx, encodedLen), builder);
    }
    


    return builder.build();
  }
  












  private static int doParseTrieToBuilder(List<CharSequence> stack, CharSequence encoded, ImmutableSet.Builder<String> builder)
  {
    int encodedLen = encoded.length();
    int idx = 0;
    char c = '\000';
    for (; 
        
        idx < encodedLen; idx++) {
      c = encoded.charAt(idx);
      if ((c == '&') || (c == '?') || (c == '!')) {
        break;
      }
    }
    
    stack.add(0, reverse(encoded.subSequence(0, idx)));
    
    if ((c == '!') || (c == '?'))
    {

      String domain = PREFIX_JOINER.join(stack);
      if (domain.length() > 0) {
        builder.add(domain);
      }
    }
    idx++;
    
    if (c != '?') {
      while (idx < encodedLen)
      {
        idx += doParseTrieToBuilder(stack, encoded.subSequence(idx, encodedLen), builder);
        if (encoded.charAt(idx) == '?')
        {
          idx++;
        }
      }
    }
    
    stack.remove(0);
    return idx;
  }
  




  private static CharSequence reverse(CharSequence s)
  {
    int length = s.length();
    if (length <= 1) {
      return s;
    }
    
    char[] buffer = new char[length];
    buffer[0] = s.charAt(length - 1);
    
    for (int i = 1; i < length; i++) {
      buffer[i] = s.charAt(length - 1 - i);
      if (Character.isSurrogatePair(buffer[i], buffer[(i - 1)])) {
        swap(buffer, i - 1, i);
      }
    }
    
    return new String(buffer);
  }
  
  private static void swap(char[] buffer, int f, int s) {
    char tmp = buffer[f];
    buffer[f] = buffer[s];
    buffer[s] = tmp;
  }
}
