package com.google.common.hash;

import com.google.common.base.Preconditions;
import com.google.common.math.LongMath;
import com.google.common.primitives.Ints;
import java.math.RoundingMode;
import java.util.Arrays;































 enum BloomFilterStrategies
  implements BloomFilter.Strategy
{
  MURMUR128_MITZ_32;
  








  private BloomFilterStrategies() {}
  








  static class BitArray
  {
    final long[] data;
    






    int bitCount;
    







    BitArray(long bits)
    {
      this(new long[Ints.checkedCast(LongMath.divide(bits, 64L, RoundingMode.CEILING))]);
    }
    
    BitArray(long[] data)
    {
      Preconditions.checkArgument(data.length > 0, "data length is zero!");
      this.data = data;
      int bitCount = 0;
      for (long value : data) {
        bitCount += Long.bitCount(value);
      }
      this.bitCount = bitCount;
    }
    
    boolean set(int index)
    {
      if (!get(index)) {
        data[(index >> 6)] |= 1L << index;
        bitCount += 1;
        return true;
      }
      return false;
    }
    
    boolean get(int index) {
      return (data[(index >> 6)] & 1L << index) != 0L;
    }
    
    int bitSize()
    {
      return data.length * 64;
    }
    
    int bitCount()
    {
      return bitCount;
    }
    
    BitArray copy() {
      return new BitArray((long[])data.clone());
    }
    
    void putAll(BitArray array)
    {
      Preconditions.checkArgument(data.length == data.length, "BitArrays must be of equal length (%s != %s)", new Object[] { Integer.valueOf(data.length), Integer.valueOf(data.length) });
      
      bitCount = 0;
      for (int i = 0; i < data.length; i++) {
        data[i] |= data[i];
        bitCount += Long.bitCount(data[i]);
      }
    }
    
    public boolean equals(Object o) {
      if ((o instanceof BitArray)) {
        BitArray bitArray = (BitArray)o;
        return Arrays.equals(data, data);
      }
      return false;
    }
    
    public int hashCode() {
      return Arrays.hashCode(data);
    }
  }
}
