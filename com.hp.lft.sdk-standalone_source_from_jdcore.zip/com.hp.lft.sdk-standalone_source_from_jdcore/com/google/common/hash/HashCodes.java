package com.google.common.hash;

import com.google.common.annotations.Beta;































@Deprecated
@Beta
public final class HashCodes
{
  private HashCodes() {}
  
  @Deprecated
  public static HashCode fromInt(int hash)
  {
    return HashCode.fromInt(hash);
  }
  






  @Deprecated
  public static HashCode fromLong(long hash)
  {
    return HashCode.fromLong(hash);
  }
  






  @Deprecated
  public static HashCode fromBytes(byte[] bytes)
  {
    return HashCode.fromBytes(bytes);
  }
}
