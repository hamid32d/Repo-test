package com.google.common.base;

import com.google.common.annotations.GwtCompatible;



























@GwtCompatible
public enum CaseFormat
{
  LOWER_HYPHEN(CharMatcher.is('-'), "-"), 
  
















  LOWER_UNDERSCORE(CharMatcher.is('_'), "_"), 
  
















  LOWER_CAMEL(CharMatcher.inRange('A', 'Z'), ""), 
  







  UPPER_CAMEL(CharMatcher.inRange('A', 'Z'), ""), 
  







  UPPER_UNDERSCORE(CharMatcher.is('_'), "_");
  




  private final CharMatcher wordBoundary;
  



  private final String wordSeparator;
  




  private CaseFormat(CharMatcher wordBoundary, String wordSeparator)
  {
    this.wordBoundary = wordBoundary;
    this.wordSeparator = wordSeparator;
  }
  




  public final String to(CaseFormat format, String str)
  {
    Preconditions.checkNotNull(format);
    Preconditions.checkNotNull(str);
    return format == this ? str : convert(format, str);
  }
  



  String convert(CaseFormat format, String s)
  {
    StringBuilder out = null;
    int i = 0;
    int j = -1;
    while ((j = wordBoundary.indexIn(s, ++j)) != -1) {
      if (i == 0)
      {
        out = new StringBuilder(s.length() + 4 * wordSeparator.length());
        out.append(format.normalizeFirstWord(s.substring(i, j)));
      } else {
        out.append(format.normalizeWord(s.substring(i, j)));
      }
      out.append(wordSeparator);
      i = j + wordSeparator.length();
    }
    return format.normalizeWord(s.substring(i));
  }
  

  abstract String normalizeWord(String paramString);
  
  private String normalizeFirstWord(String word)
  {
    return this == LOWER_CAMEL ? Ascii.toLowerCase(word) : normalizeWord(word);
  }
  
  private static String firstCharOnlyToUpper(String word) {
    return word.length() + Ascii.toUpperCase(word.charAt(0)) + Ascii.toLowerCase(word.substring(1));
  }
}
