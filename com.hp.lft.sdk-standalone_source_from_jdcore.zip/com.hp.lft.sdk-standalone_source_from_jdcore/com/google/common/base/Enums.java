package com.google.common.base;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import java.io.Serializable;
import java.lang.reflect.Field;
import javax.annotation.Nullable;



































@GwtCompatible(emulated=true)
@Beta
public final class Enums
{
  private Enums() {}
  
  @GwtIncompatible("reflection")
  public static Field getField(Enum<?> enumValue)
  {
    Class<?> clazz = enumValue.getDeclaringClass();
    try {
      return clazz.getDeclaredField(enumValue.name());
    } catch (NoSuchFieldException impossible) {
      throw new AssertionError(impossible);
    }
  }
  







  public static <T extends Enum<T>> Function<String, T> valueOfFunction(Class<T> enumClass)
  {
    return new ValueOfFunction(enumClass, null);
  }
  

  private static final class ValueOfFunction<T extends Enum<T>>
    implements Function<String, T>, Serializable
  {
    private final Class<T> enumClass;
    
    private static final long serialVersionUID = 0L;
    
    private ValueOfFunction(Class<T> enumClass)
    {
      this.enumClass = ((Class)Preconditions.checkNotNull(enumClass));
    }
    
    public T apply(String value)
    {
      try {
        return Enum.valueOf(enumClass, value);
      } catch (IllegalArgumentException e) {}
      return null;
    }
    
    public boolean equals(@Nullable Object obj)
    {
      return ((obj instanceof ValueOfFunction)) && (enumClass.equals(enumClass));
    }
    
    public int hashCode()
    {
      return enumClass.hashCode();
    }
    
    public String toString() {
      return "Enums.valueOf(" + enumClass + ")";
    }
  }
  









  public static <T extends Enum<T>> Optional<T> getIfPresent(Class<T> enumClass, String value)
  {
    Preconditions.checkNotNull(enumClass);
    Preconditions.checkNotNull(value);
    try {
      return Optional.of(Enum.valueOf(enumClass, value));
    } catch (IllegalArgumentException iae) {}
    return Optional.absent();
  }
}
