package com.google.common.base;

public abstract interface FinalizableReference
{
  public abstract void finalizeReferent();
}
