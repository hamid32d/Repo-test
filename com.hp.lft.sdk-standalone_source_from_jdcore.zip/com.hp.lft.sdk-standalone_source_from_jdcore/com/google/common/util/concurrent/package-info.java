package com.google.common.util.concurrent;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
abstract interface package-info {}
