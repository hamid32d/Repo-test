package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.collect.ForwardingObject;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;






























@Deprecated
@Beta
public abstract class ForwardingService
  extends ForwardingObject
  implements Service
{
  protected ForwardingService() {}
  
  protected abstract Service delegate();
  
  @Deprecated
  public ListenableFuture<Service.State> start()
  {
    return delegate().start();
  }
  
  public Service.State state() {
    return delegate().state();
  }
  
  @Deprecated
  public ListenableFuture<Service.State> stop()
  {
    return delegate().stop();
  }
  
  @Deprecated
  public Service.State startAndWait()
  {
    return delegate().startAndWait();
  }
  
  @Deprecated
  public Service.State stopAndWait()
  {
    return delegate().stopAndWait();
  }
  
  public boolean isRunning() {
    return delegate().isRunning();
  }
  


  public void addListener(Service.Listener listener, Executor executor)
  {
    delegate().addListener(listener, executor);
  }
  


  public Throwable failureCause()
  {
    return delegate().failureCause();
  }
  


  public Service startAsync()
  {
    delegate().startAsync();
    return this;
  }
  


  public Service stopAsync()
  {
    delegate().stopAsync();
    return this;
  }
  

  public void awaitRunning()
  {
    delegate().awaitRunning();
  }
  

  public void awaitRunning(long timeout, TimeUnit unit)
    throws TimeoutException
  {
    delegate().awaitRunning(timeout, unit);
  }
  


  public void awaitTerminated()
  {
    delegate().awaitTerminated();
  }
  

  public void awaitTerminated(long timeout, TimeUnit unit)
    throws TimeoutException
  {
    delegate().awaitTerminated(timeout, unit);
  }
  





  protected Service.State standardStartAndWait()
  {
    return (Service.State)Futures.getUnchecked(start());
  }
  





  protected Service.State standardStopAndWait()
  {
    return (Service.State)Futures.getUnchecked(stop());
  }
}
