package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Objects.ToStringHelper;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicates;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Collections2;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.ImmutableMultimap.Builder;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.Immutable;
import javax.inject.Inject;
import javax.inject.Singleton;








































































@Singleton
@Beta
public final class ServiceManager
{
  private static final Logger logger = Logger.getLogger(ServiceManager.class.getName());
  





  private final ServiceManagerState state;
  





  private final ImmutableMap<Service, ServiceListener> services;
  






  @Beta
  public static abstract class Listener
  {
    public Listener() {}
    





    public void healthy() {}
    





    public void stopped() {}
    





    public void failure(Service service) {}
  }
  





  public ServiceManager(Iterable<? extends Service> services)
  {
    ImmutableList<Service> copy = ImmutableList.copyOf(services);
    if (copy.isEmpty())
    {

      logger.log(Level.WARNING, "ServiceManager configured with no services.  Is your application configured properly?", new EmptyServiceManagerWarning(null));
      

      copy = ImmutableList.of(new NoOpService(null));
    }
    state = new ServiceManagerState(copy.size());
    ImmutableMap.Builder<Service, ServiceListener> builder = ImmutableMap.builder();
    Executor executor = MoreExecutors.sameThreadExecutor();
    for (Service service : copy) {
      ServiceListener listener = new ServiceListener(service, state);
      service.addListener(listener, executor);
      

      Preconditions.checkArgument(service.state() == Service.State.NEW, "Can only manage NEW services, %s", new Object[] { service });
      builder.put(service, listener);
    }
    this.services = builder.build();
  }
  






  @Inject
  ServiceManager(Set<Service> services)
  {
    this(services);
  }
  



















  public void addListener(Listener listener, Executor executor)
  {
    state.addListener(listener, executor);
  }
  











  public void addListener(Listener listener)
  {
    state.addListener(listener, MoreExecutors.sameThreadExecutor());
  }
  







  public ServiceManager startAsync()
  {
    for (Map.Entry<Service, ServiceListener> entry : services.entrySet()) {
      Service service = (Service)entry.getKey();
      Service.State state = service.state();
      Preconditions.checkState(state == Service.State.NEW, "Service %s is %s, cannot start it.", new Object[] { service, state });
    }
    
    for (ServiceListener service : services.values()) {
      try {
        service.start();

      }
      catch (IllegalStateException e)
      {

        logger.log(Level.WARNING, "Unable to start Service " + service, e);
      }
    }
    return this;
  }
  







  public void awaitHealthy()
  {
    state.awaitHealthy();
    Preconditions.checkState(isHealthy(), "Expected to be healthy after starting");
  }
  









  public void awaitHealthy(long timeout, TimeUnit unit)
    throws TimeoutException
  {
    if (!state.awaitHealthy(timeout, unit))
    {





      throw new TimeoutException("Timeout waiting for the services to become healthy.");
    }
    Preconditions.checkState(isHealthy(), "Expected to be healthy after starting");
  }
  





  public ServiceManager stopAsync()
  {
    for (Service service : services.keySet()) {
      service.stop();
    }
    return this;
  }
  




  public void awaitStopped()
  {
    state.awaitStopped();
  }
  







  public void awaitStopped(long timeout, TimeUnit unit)
    throws TimeoutException
  {
    if (!state.awaitStopped(timeout, unit)) {
      throw new TimeoutException("Timeout waiting for the services to stop.");
    }
  }
  





  public boolean isHealthy()
  {
    for (Service service : services.keySet()) {
      if (!service.isRunning()) {
        return false;
      }
    }
    return true;
  }
  





  public ImmutableMultimap<Service.State, Service> servicesByState()
  {
    ImmutableMultimap.Builder<Service.State, Service> builder = ImmutableMultimap.builder();
    for (Service service : services.keySet()) {
      if (!(service instanceof NoOpService)) {
        builder.put(service.state(), service);
      }
    }
    return builder.build();
  }
  






  public ImmutableMap<Service, Long> startupTimes()
  {
    List<Map.Entry<Service, Long>> loadTimes = Lists.newArrayListWithCapacity(services.size());
    for (Map.Entry<Service, ServiceListener> entry : services.entrySet()) {
      Service service = (Service)entry.getKey();
      Service.State state = service.state();
      if (((state != Service.State.NEW ? 1 : 0) & (state != Service.State.STARTING ? 1 : 0) & (!(service instanceof NoOpService) ? 1 : 0)) != 0) {
        loadTimes.add(Maps.immutableEntry(service, Long.valueOf(((ServiceListener)entry.getValue()).startupTimeMillis())));
      }
    }
    Collections.sort(loadTimes, Ordering.natural().onResultOf(new Function()
    {
      public Long apply(Map.Entry<Service, Long> input) {
        return (Long)input.getValue();
      }
    }));
    ImmutableMap.Builder<Service, Long> builder = ImmutableMap.builder();
    for (Map.Entry<Service, Long> entry : loadTimes) {
      builder.put(entry);
    }
    return builder.build();
  }
  
  public String toString() {
    return Objects.toStringHelper(ServiceManager.class).add("services", Collections2.filter(services.keySet(), Predicates.not(Predicates.instanceOf(NoOpService.class)))).toString();
  }
  





  private static final class ServiceManagerState
  {
    final Monitor monitor = new Monitor();
    

    final int numberOfServices;
    

    @GuardedBy("monitor")
    int unstartedServices;
    
    @GuardedBy("monitor")
    int unstoppedServices;
    
    final Monitor.Guard awaitHealthGuard = new Monitor.Guard(monitor)
    {
      public boolean isSatisfied() {
        return (unstartedServices == 0 ? 1 : 0) | (unstoppedServices != numberOfServices ? 1 : 0);
      }
    };
    


    final Monitor.Guard stoppedGuard = new Monitor.Guard(monitor) {
      public boolean isSatisfied() {
        return unstoppedServices == 0;
      }
    };
    @GuardedBy("monitor")
    final List<ServiceManager.ListenerExecutorPair> listeners = Lists.newArrayList();
    







    @GuardedBy("monitor")
    final ExecutionQueue queuedListeners = new ExecutionQueue();
    
    ServiceManagerState(int numberOfServices)
    {
      this.numberOfServices = numberOfServices;
      unstoppedServices = numberOfServices;
      unstartedServices = numberOfServices;
    }
    
    void addListener(ServiceManager.Listener listener, Executor executor) {
      Preconditions.checkNotNull(listener, "listener");
      Preconditions.checkNotNull(executor, "executor");
      monitor.enter();
      try
      {
        if ((unstartedServices > 0) || (unstoppedServices > 0)) {
          listeners.add(new ServiceManager.ListenerExecutorPair(listener, executor));
        }
      } finally {
        monitor.leave();
      }
    }
    
    void awaitHealthy() {
      monitor.enterWhenUninterruptibly(awaitHealthGuard);
      monitor.leave();
    }
    
    boolean awaitHealthy(long timeout, TimeUnit unit) {
      if (monitor.enterWhenUninterruptibly(awaitHealthGuard, timeout, unit)) {
        monitor.leave();
        return true;
      }
      return false;
    }
    
    void awaitStopped() {
      monitor.enterWhenUninterruptibly(stoppedGuard);
      monitor.leave();
    }
    
    boolean awaitStopped(long timeout, TimeUnit unit) {
      if (monitor.enterWhenUninterruptibly(stoppedGuard, timeout, unit)) {
        monitor.leave();
        return true;
      }
      return false;
    }
    





    @GuardedBy("monitor")
    private void serviceFinishedStarting(Service service, boolean currentlyHealthy)
    {
      Preconditions.checkState(unstartedServices > 0, "All services should have already finished starting but %s just finished.", new Object[] { service });
      
      unstartedServices -= 1;
      if ((currentlyHealthy) && (unstartedServices == 0) && (unstoppedServices == numberOfServices))
      {







        for (final ServiceManager.ListenerExecutorPair pair : listeners) {
          queuedListeners.add(new Runnable()
          {
            public void run() { pairlistener.healthy(); } }, executor);
        }
      }
    }
    




    @GuardedBy("monitor")
    private void serviceTerminated(Service service)
    {
      serviceStopped(service);
    }
    


    @GuardedBy("monitor")
    private void serviceFailed(final Service service)
    {
      for (final ServiceManager.ListenerExecutorPair pair : listeners) {
        queuedListeners.add(new Runnable()
        {
          public void run() { pairlistener.failure(service); } }, executor);
      }
      

      serviceStopped(service);
    }
    




    @GuardedBy("monitor")
    private void serviceStopped(Service service)
    {
      Preconditions.checkState(unstoppedServices > 0, "All services should have already stopped but %s just stopped.", new Object[] { service });
      
      unstoppedServices -= 1;
      if (unstoppedServices == 0) {
        Preconditions.checkState(unstartedServices == 0, "All services are stopped but %d services haven't finished starting", new Object[] { Integer.valueOf(unstartedServices) });
        

        for (final ServiceManager.ListenerExecutorPair pair : listeners) {
          queuedListeners.add(new Runnable()
          {
            public void run() { pairlistener.stopped(); } }, executor);
        }
        


        listeners.clear();
      }
    }
    
    private void executeListeners()
    {
      Preconditions.checkState(!monitor.isOccupiedByCurrentThread(), "It is incorrect to execute listeners with the monitor held.");
      
      queuedListeners.execute();
    }
  }
  



  private static final class ServiceListener
    extends Service.Listener
  {
    @GuardedBy("watch")
    final Stopwatch watch = Stopwatch.createUnstarted();
    
    final Service service;
    
    final ServiceManager.ServiceManagerState state;
    

    ServiceListener(Service service, ServiceManager.ServiceManagerState state)
    {
      this.service = service;
      this.state = state;
    }
    

    public void starting()
    {
      startTimer();
    }
    
    public void running() {
      state.monitor.enter();
      try {
        finishedStarting(true);
      } finally {
        state.monitor.leave();
        ServiceManager.ServiceManagerState.access$200(state);
      }
    }
    
    public void stopping(Service.State from) {
      if (from == Service.State.STARTING) {
        state.monitor.enter();
        try {
          finishedStarting(false);
        } finally {
          state.monitor.leave();
          ServiceManager.ServiceManagerState.access$200(state);
        }
      }
    }
    
    public void terminated(Service.State from) {
      if (!(service instanceof ServiceManager.NoOpService)) {
        ServiceManager.logger.log(Level.FINE, "Service {0} has terminated. Previous state was: {1}", new Object[] { service, from });
      }
      
      state.monitor.enter();
      try {
        if (from == Service.State.NEW)
        {

          startTimer();
          finishedStarting(false);
        }
        ServiceManager.ServiceManagerState.access$400(state, service);
      } finally {
        state.monitor.leave();
        ServiceManager.ServiceManagerState.access$200(state);
      }
    }
    
    public void failed(Service.State from, Throwable failure) {
      ServiceManager.logger.log(Level.SEVERE, "Service " + service + " has failed in the " + from + " state.", failure);
      
      state.monitor.enter();
      try {
        if (from == Service.State.STARTING) {
          finishedStarting(false);
        }
        ServiceManager.ServiceManagerState.access$500(state, service);
      } finally {
        state.monitor.leave();
        ServiceManager.ServiceManagerState.access$200(state);
      }
    }
    





    @GuardedBy("monitor")
    void finishedStarting(boolean currentlyHealthy)
    {
      synchronized (watch) {
        watch.stop();
        if (!(service instanceof ServiceManager.NoOpService)) {
          ServiceManager.logger.log(Level.FINE, "Started {0} in {1} ms.", new Object[] { service, Long.valueOf(startupTimeMillis()) });
        }
      }
      
      ServiceManager.ServiceManagerState.access$600(state, service, currentlyHealthy);
    }
    
    void start() {
      startTimer();
      service.startAsync();
    }
    
    void startTimer()
    {
      synchronized (watch) {
        if (!watch.isRunning()) {
          watch.start();
          if (!(service instanceof ServiceManager.NoOpService)) {
            ServiceManager.logger.log(Level.FINE, "Starting {0}.", service);
          }
        }
      }
    }
    
    long startupTimeMillis()
    {
      synchronized (watch) {
        return watch.elapsed(TimeUnit.MILLISECONDS);
      }
    }
  }
  
  @Immutable
  private static final class ListenerExecutorPair {
    final ServiceManager.Listener listener;
    final Executor executor;
    
    ListenerExecutorPair(ServiceManager.Listener listener, Executor executor) {
      this.listener = listener;
      this.executor = executor;
    }
  }
  


  private static final class NoOpService
    extends AbstractService
  {
    private NoOpService() {}
    


    protected void doStart() { notifyStarted(); }
    protected void doStop() { notifyStopped(); }
  }
  
  private static final class EmptyServiceManagerWarning
    extends Throwable
  {
    private EmptyServiceManagerWarning() {}
  }
}
