package com.google.common.util.concurrent;

import com.google.common.base.Preconditions;
import com.google.common.collect.Queues;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;







































@ThreadSafe
final class ExecutionQueue
{
  private static final Logger logger = Logger.getLogger(ExecutionQueue.class.getName());
  private final ConcurrentLinkedQueue<RunnableExecutorPair> queuedListeners;
  
  ExecutionQueue() { queuedListeners = Queues.newConcurrentLinkedQueue();
    




    lock = new ReentrantLock();
  }
  


  void add(Runnable runnable, Executor executor)
  {
    queuedListeners.add(new RunnableExecutorPair(runnable, executor));
  }
  






  private final ReentrantLock lock;
  




  void execute()
  {
    Iterator<RunnableExecutorPair> iterator = queuedListeners.iterator();
    while (iterator.hasNext()) {
      ((RunnableExecutorPair)iterator.next()).submit();
      iterator.remove();
    }
  }
  





  private final class RunnableExecutorPair
    implements Runnable
  {
    private final Executor executor;
    




    private final Runnable runnable;
    




    @GuardedBy("lock")
    private boolean hasBeenExecuted = false;
    
    RunnableExecutorPair(Runnable runnable, Executor executor)
    {
      this.runnable = ((Runnable)Preconditions.checkNotNull(runnable));
      this.executor = ((Executor)Preconditions.checkNotNull(executor));
    }
    
    private void submit()
    {
      lock.lock();
      try {
        if (!hasBeenExecuted) {
          try {
            executor.execute(this);
          } catch (Exception e) {
            ExecutionQueue.logger.log(Level.SEVERE, "Exception while executing listener " + runnable + " with executor " + executor, e);
          }
          
        }
      }
      finally
      {
        if (lock.isHeldByCurrentThread()) {
          hasBeenExecuted = true;
          lock.unlock();
        }
      }
    }
    


    public final void run()
    {
      if (lock.isHeldByCurrentThread()) {
        hasBeenExecuted = true;
        lock.unlock();
      }
      runnable.run();
    }
  }
}
