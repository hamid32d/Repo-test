package javax.websocket;

public abstract interface MessageHandler
{
  public static abstract interface Partial<T>
    extends MessageHandler
  {
    public abstract void onMessage(T paramT, boolean paramBoolean);
  }
  
  public static abstract interface Whole<T>
    extends MessageHandler
  {
    public abstract void onMessage(T paramT);
  }
}
