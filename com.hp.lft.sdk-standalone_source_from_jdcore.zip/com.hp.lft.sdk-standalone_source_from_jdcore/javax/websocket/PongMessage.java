package javax.websocket;

import java.nio.ByteBuffer;

public abstract interface PongMessage
{
  public abstract ByteBuffer getApplicationData();
}
