package javax.websocket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


































































































































public abstract interface ClientEndpointConfig
  extends EndpointConfig
{
  public abstract List<String> getPreferredSubprotocols();
  
  public abstract List<Extension> getExtensions();
  
  public abstract Configurator getConfigurator();
  
  public static final class Builder
  {
    private List<String> preferredSubprotocols = Collections.emptyList();
    private List<Extension> extensions = Collections.emptyList();
    private List<Class<? extends Encoder>> encoders = Collections.emptyList();
    private List<Class<? extends Decoder>> decoders = Collections.emptyList();
    private ClientEndpointConfig.Configurator clientEndpointConfigurator = new ClientEndpointConfig.Configurator() {};
    





    private Builder() {}
    




    public static Builder create()
    {
      return new Builder();
    }
    





    public ClientEndpointConfig build()
    {
      return new DefaultClientEndpointConfig(Collections.unmodifiableList(preferredSubprotocols), Collections.unmodifiableList(extensions), Collections.unmodifiableList(encoders), Collections.unmodifiableList(decoders), clientEndpointConfigurator);
    }
    












    public Builder configurator(ClientEndpointConfig.Configurator clientEndpointConfigurator)
    {
      this.clientEndpointConfigurator = clientEndpointConfigurator;
      return this;
    }
    








    public Builder preferredSubprotocols(List<String> preferredSubprotocols)
    {
      this.preferredSubprotocols = (preferredSubprotocols == null ? new ArrayList() : preferredSubprotocols);
      return this;
    }
    








    public Builder extensions(List<Extension> extensions)
    {
      this.extensions = (extensions == null ? new ArrayList() : extensions);
      return this;
    }
    





    public Builder encoders(List<Class<? extends Encoder>> encoders)
    {
      this.encoders = (encoders == null ? new ArrayList() : encoders);
      return this;
    }
    





    public Builder decoders(List<Class<? extends Decoder>> decoders)
    {
      this.decoders = (decoders == null ? new ArrayList() : decoders);
      return this;
    }
  }
  
  public static class Configurator
  {
    public Configurator() {}
    
    public void beforeRequest(Map<String, List<String>> headers) {}
    
    public void afterResponse(HandshakeResponse hr) {}
  }
}
