package javax.websocket.server;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.websocket.Decoder;
import javax.websocket.Encoder;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
public @interface ServerEndpoint
{
  String value();
  
  String[] subprotocols() default {};
  
  Class<? extends Decoder>[] decoders() default {};
  
  Class<? extends Encoder>[] encoders() default {};
  
  Class<? extends ServerEndpointConfig.Configurator> configurator() default ServerEndpointConfig.Configurator.class;
}
