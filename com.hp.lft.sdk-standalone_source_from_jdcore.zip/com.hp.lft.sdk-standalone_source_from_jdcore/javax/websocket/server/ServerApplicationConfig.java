package javax.websocket.server;

import java.util.Set;
import javax.websocket.Endpoint;

public abstract interface ServerApplicationConfig
{
  public abstract Set<ServerEndpointConfig> getEndpointConfigs(Set<Class<? extends Endpoint>> paramSet);
  
  public abstract Set<Class<?>> getAnnotatedEndpointClasses(Set<Class<?>> paramSet);
}
