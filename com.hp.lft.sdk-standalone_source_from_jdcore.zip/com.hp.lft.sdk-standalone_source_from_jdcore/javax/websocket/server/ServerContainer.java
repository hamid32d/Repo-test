package javax.websocket.server;

import javax.websocket.DeploymentException;
import javax.websocket.WebSocketContainer;

public abstract interface ServerContainer
  extends WebSocketContainer
{
  public abstract void addEndpoint(Class<?> paramClass)
    throws DeploymentException;
  
  public abstract void addEndpoint(ServerEndpointConfig paramServerEndpointConfig)
    throws DeploymentException;
}
