package javax.websocket.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import javax.websocket.Decoder;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;
import javax.websocket.Extension;
import javax.websocket.HandshakeResponse;






















































































public abstract interface ServerEndpointConfig
  extends EndpointConfig
{
  public abstract Class<?> getEndpointClass();
  
  public abstract String getPath();
  
  public abstract List<String> getSubprotocols();
  
  public abstract List<Extension> getExtensions();
  
  public abstract Configurator getConfigurator();
  
  public static class Configurator
  {
    private Configurator containerDefaultConfigurator;
    
    public Configurator() {}
    
    static Configurator fetchContainerDefaultConfigurator()
    {
      Iterator i$ = ServiceLoader.load(Configurator.class).iterator(); if (i$.hasNext()) { Configurator impl = (Configurator)i$.next();
        return impl;
      }
      throw new RuntimeException("Cannot load platform configurator");
    }
    
    Configurator getContainerDefaultConfigurator() {
      if (containerDefaultConfigurator == null) {
        containerDefaultConfigurator = fetchContainerDefaultConfigurator();
      }
      return containerDefaultConfigurator;
    }
    

















    public String getNegotiatedSubprotocol(List<String> supported, List<String> requested)
    {
      return getContainerDefaultConfigurator().getNegotiatedSubprotocol(supported, requested);
    }
    














    public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested)
    {
      return getContainerDefaultConfigurator().getNegotiatedExtensions(installed, requested);
    }
    
















    public boolean checkOrigin(String originHeaderValue)
    {
      return getContainerDefaultConfigurator().checkOrigin(originHeaderValue);
    }
    




















    public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {}
    



















    public <T> T getEndpointInstance(Class<T> endpointClass)
      throws InstantiationException
    {
      return getContainerDefaultConfigurator().getEndpointInstance(endpointClass);
    }
  }
  








  public static final class Builder
  {
    private String path;
    







    private Class<?> endpointClass;
    






    private List<String> subprotocols = Collections.emptyList();
    private List<Extension> extensions = Collections.emptyList();
    private List<Class<? extends Encoder>> encoders = Collections.emptyList();
    private List<Class<? extends Decoder>> decoders = Collections.emptyList();
    




    private ServerEndpointConfig.Configurator serverEndpointConfigurator;
    




    public static Builder create(Class<?> endpointClass, String path)
    {
      return new Builder(endpointClass, path);
    }
    




    private Builder() {}
    



    public ServerEndpointConfig build()
    {
      return new DefaultServerEndpointConfig(endpointClass, path, Collections.unmodifiableList(subprotocols), Collections.unmodifiableList(extensions), Collections.unmodifiableList(encoders), Collections.unmodifiableList(decoders), serverEndpointConfigurator);
    }
    







    private Builder(Class endpointClass, String path)
    {
      if (endpointClass == null) {
        throw new IllegalArgumentException("endpointClass cannot be null");
      }
      this.endpointClass = endpointClass;
      if ((path == null) || (!path.startsWith("/"))) {
        throw new IllegalStateException("Path cannot be null and must begin with /");
      }
      this.path = path;
    }
    





    public Builder encoders(List<Class<? extends Encoder>> encoders)
    {
      this.encoders = (encoders == null ? new ArrayList() : encoders);
      return this;
    }
    





    public Builder decoders(List<Class<? extends Decoder>> decoders)
    {
      this.decoders = (decoders == null ? new ArrayList() : decoders);
      return this;
    }
    





    public Builder subprotocols(List<String> subprotocols)
    {
      this.subprotocols = (subprotocols == null ? new ArrayList() : subprotocols);
      return this;
    }
    






    public Builder extensions(List<Extension> extensions)
    {
      this.extensions = (extensions == null ? new ArrayList() : extensions);
      return this;
    }
    






    public Builder configurator(ServerEndpointConfig.Configurator serverEndpointConfigurator)
    {
      this.serverEndpointConfigurator = serverEndpointConfigurator;
      return this;
    }
  }
}
