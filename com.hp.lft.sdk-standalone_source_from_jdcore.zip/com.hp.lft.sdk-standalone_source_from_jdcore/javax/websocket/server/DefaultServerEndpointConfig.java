package javax.websocket.server;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.websocket.Decoder;
import javax.websocket.Encoder;
import javax.websocket.Endpoint;
import javax.websocket.Extension;














































final class DefaultServerEndpointConfig
  implements ServerEndpointConfig
{
  private String path;
  private Class<?> endpointClass;
  private List<String> subprotocols;
  private List<Extension> extensions;
  private List<Class<? extends Encoder>> encoders;
  private List<Class<? extends Decoder>> decoders;
  private Map<String, Object> userProperties = new HashMap();
  



  private ServerEndpointConfig.Configurator serverEndpointConfigurator;
  



  DefaultServerEndpointConfig(Class<?> endpointClass, String path, List<String> subprotocols, List<Extension> extensions, List<Class<? extends Encoder>> encoders, List<Class<? extends Decoder>> decoders, ServerEndpointConfig.Configurator serverEndpointConfigurator)
  {
    this.path = path;
    this.endpointClass = endpointClass;
    this.subprotocols = Collections.unmodifiableList(subprotocols);
    this.extensions = Collections.unmodifiableList(extensions);
    this.encoders = Collections.unmodifiableList(encoders);
    this.decoders = Collections.unmodifiableList(decoders);
    if (serverEndpointConfigurator == null) {
      this.serverEndpointConfigurator = ServerEndpointConfig.Configurator.fetchContainerDefaultConfigurator();
    } else {
      this.serverEndpointConfigurator = serverEndpointConfigurator;
    }
  }
  





  public Class<?> getEndpointClass()
  {
    return endpointClass;
  }
  





  DefaultServerEndpointConfig(Class<? extends Endpoint> endpointClass, String path)
  {
    this.path = path;
    this.endpointClass = endpointClass;
  }
  






  public List<Class<? extends Encoder>> getEncoders()
  {
    return encoders;
  }
  








  public List<Class<? extends Decoder>> getDecoders()
  {
    return decoders;
  }
  






  public String getPath()
  {
    return path;
  }
  





  public ServerEndpointConfig.Configurator getConfigurator()
  {
    return serverEndpointConfigurator;
  }
  



  public final Map<String, Object> getUserProperties()
  {
    return userProperties;
  }
  
  public final List<String> getSubprotocols()
  {
    return subprotocols;
  }
  
  public final List<Extension> getExtensions()
  {
    return extensions;
  }
}
