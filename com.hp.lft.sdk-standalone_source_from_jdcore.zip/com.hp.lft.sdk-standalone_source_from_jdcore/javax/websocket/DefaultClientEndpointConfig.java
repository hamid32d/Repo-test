package javax.websocket;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;











































final class DefaultClientEndpointConfig
  implements ClientEndpointConfig
{
  private List<String> preferredSubprotocols;
  private List<Extension> extensions;
  private List<Class<? extends Encoder>> encoders;
  private List<Class<? extends Decoder>> decoders;
  private Map<String, Object> userProperties = new HashMap();
  


  private ClientEndpointConfig.Configurator clientEndpointConfigurator;
  


  DefaultClientEndpointConfig(List<String> preferredSubprotocols, List<Extension> extensions, List<Class<? extends Encoder>> encoders, List<Class<? extends Decoder>> decoders, ClientEndpointConfig.Configurator clientEndpointConfigurator)
  {
    this.preferredSubprotocols = Collections.unmodifiableList(preferredSubprotocols);
    this.extensions = Collections.unmodifiableList(extensions);
    this.encoders = Collections.unmodifiableList(encoders);
    this.decoders = Collections.unmodifiableList(decoders);
    this.clientEndpointConfigurator = clientEndpointConfigurator;
  }
  






  public List<String> getPreferredSubprotocols()
  {
    return preferredSubprotocols;
  }
  








  public List<Extension> getExtensions()
  {
    return extensions;
  }
  







  public List<Class<? extends Encoder>> getEncoders()
  {
    return encoders;
  }
  







  public List<Class<? extends Decoder>> getDecoders()
  {
    return decoders;
  }
  




  public final Map<String, Object> getUserProperties()
  {
    return userProperties;
  }
  
  public ClientEndpointConfig.Configurator getConfigurator()
  {
    return clientEndpointConfigurator;
  }
}
