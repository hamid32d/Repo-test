package javax.websocket;

import java.util.List;

public abstract interface Extension
{
  public abstract String getName();
  
  public abstract List<Parameter> getParameters();
  
  public static abstract interface Parameter
  {
    public abstract String getName();
    
    public abstract String getValue();
  }
}
