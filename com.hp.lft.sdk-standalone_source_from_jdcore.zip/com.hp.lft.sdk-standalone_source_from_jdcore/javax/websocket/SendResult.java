package javax.websocket;


















public final class SendResult
{
  private final Throwable exception;
  
















  private final boolean isOK;
  
















  public SendResult(Throwable exception)
  {
    this.exception = exception;
    isOK = false;
  }
  


  public SendResult()
  {
    exception = null;
    isOK = true;
  }
  




  public Throwable getException()
  {
    return exception;
  }
  




  public boolean isOK()
  {
    return isOK;
  }
}
