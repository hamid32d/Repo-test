package javax.websocket;

import java.util.List;
import java.util.Map;

public abstract interface HandshakeResponse
{
  public static final String SEC_WEBSOCKET_ACCEPT = "Sec-WebSocket-Accept";
  
  public abstract Map<String, List<String>> getHeaders();
}
