package javax.websocket;

import java.util.List;
import java.util.Map;

public abstract interface EndpointConfig
{
  public abstract List<Class<? extends Encoder>> getEncoders();
  
  public abstract List<Class<? extends Decoder>> getDecoders();
  
  public abstract Map<String, Object> getUserProperties();
}
