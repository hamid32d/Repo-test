package javax.websocket;

import java.nio.ByteBuffer;






















































public class DecodeException
  extends Exception
{
  private final ByteBuffer bb;
  private final String encodedString;
  private static final long serialVersionUID = 6L;
  
  public DecodeException(ByteBuffer bb, String message, Throwable cause)
  {
    super(message, cause);
    encodedString = null;
    this.bb = bb;
  }
  










  public DecodeException(String encodedString, String message, Throwable cause)
  {
    super(message, cause);
    this.encodedString = encodedString;
    bb = null;
  }
  










  public DecodeException(ByteBuffer bb, String message)
  {
    super(message);
    encodedString = null;
    this.bb = bb;
  }
  










  public DecodeException(String encodedString, String message)
  {
    super(message);
    this.encodedString = encodedString;
    bb = null;
  }
  






  public ByteBuffer getBytes()
  {
    return bb;
  }
  






  public String getText()
  {
    return encodedString;
  }
}
