package javax.websocket;

public abstract interface SendHandler
{
  public abstract void onResult(SendResult paramSendResult);
}
