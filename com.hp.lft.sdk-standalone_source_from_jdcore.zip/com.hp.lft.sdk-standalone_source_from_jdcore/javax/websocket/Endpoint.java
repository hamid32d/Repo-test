package javax.websocket;

public abstract class Endpoint
{
  public Endpoint() {}
  
  public abstract void onOpen(Session paramSession, EndpointConfig paramEndpointConfig);
  
  public void onClose(Session session, CloseReason closeReason) {}
  
  public void onError(Session session, Throwable thr) {}
}
