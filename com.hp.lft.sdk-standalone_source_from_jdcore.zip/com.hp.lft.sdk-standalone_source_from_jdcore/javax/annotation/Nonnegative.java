package javax.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.RetentionPolicy;
import javax.annotation.meta.TypeQualifier;
import javax.annotation.meta.When;

@java.lang.annotation.Documented
@TypeQualifier(applicableTo=Number.class)
@java.lang.annotation.Retention(RetentionPolicy.RUNTIME)
public @interface Nonnegative
{
  When when() default When.ALWAYS;
  
  public static class Checker implements javax.annotation.meta.TypeQualifierValidator<Nonnegative>
  {
    public Checker() {}
    
    public When forConstantValue(Nonnegative annotation, Object v)
    {
      if (!(v instanceof Number)) {
        return When.NEVER;
      }
      Number value = (Number)v;
      boolean isNegative; boolean isNegative; if ((value instanceof Long)) {
        isNegative = value.longValue() < 0L; } else { boolean isNegative;
        if ((value instanceof Double)) {
          isNegative = value.doubleValue() < 0.0D; } else { boolean isNegative;
          if ((value instanceof Float)) {
            isNegative = value.floatValue() < 0.0F;
          } else
            isNegative = value.intValue() < 0;
        } }
      if (isNegative) {
        return When.NEVER;
      }
      return When.ALWAYS;
    }
  }
}
