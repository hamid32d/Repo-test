package javax.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.RetentionPolicy;
import javax.annotation.meta.TypeQualifier;
import javax.annotation.meta.When;

@java.lang.annotation.Documented
@TypeQualifier
@java.lang.annotation.Retention(RetentionPolicy.RUNTIME)
public @interface Nonnull
{
  When when() default When.ALWAYS;
  
  public static class Checker implements javax.annotation.meta.TypeQualifierValidator<Nonnull>
  {
    public Checker() {}
    
    public When forConstantValue(Nonnull qualifierqualifierArgument, Object value)
    {
      if (value == null)
        return When.NEVER;
      return When.ALWAYS;
    }
  }
}
