package javax.annotation;

import java.util.regex.Pattern;
import javax.annotation.meta.TypeQualifier;
import javax.annotation.meta.When;

@java.lang.annotation.Documented
@TypeQualifier(applicableTo=String.class)
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface MatchesPattern
{
  @RegEx
  String value();
  
  int flags() default 0;
  
  public static class Checker implements javax.annotation.meta.TypeQualifierValidator<MatchesPattern>
  {
    public Checker() {}
    
    public When forConstantValue(MatchesPattern annotation, Object value)
    {
      Pattern p = Pattern.compile(annotation.value(), annotation.flags());
      if (p.matcher((String)value).matches())
        return When.ALWAYS;
      return When.NEVER;
    }
  }
}
